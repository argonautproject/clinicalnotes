package http://www.fhir.org/guides/test3/ImplementationGuide/ig;

import org.hl7.fhir.r4.model.ProfilingWrapper;

public class ExampleExtension {

}
