package http://fhir.org/guides/argonaut-clinicalnotes/ImplementationGuide/ig;

import org.hl7.fhir.r4.model.ProfilingWrapper;

public class ClinicalNotesPlusUSCoreDocumentReferenceDifferentialProfile {

}
