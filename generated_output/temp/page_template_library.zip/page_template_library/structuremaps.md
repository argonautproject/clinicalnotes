---
title: Structure Maps defined as part of this Guide
layout: default
active: structuremaps
---
#### Structure Maps

This is the mappings between FHIR resources and Logical Models:

{% include list-simple-structuremaps.xhtml %}

---
