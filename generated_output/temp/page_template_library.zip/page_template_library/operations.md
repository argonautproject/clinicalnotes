---
title: OperationDefinitions defined for this Guide
layout: default
active: operations
---

These OperatioDefinitions have been defined for this implementation guide.

{% raw %}{% include list-simple-operationdefinitions.xhtml %}{% endraw %} - to activate remove the liquid tags 'raw'

---
