---
title: Extensions defined for this Guide
layout: default
active: extensions
---

These extensions have been defined for this implementation guide.
{% include list-simple-extensions.xhtml %}
