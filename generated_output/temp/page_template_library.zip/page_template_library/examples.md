---
title: Examples
layout: default
active: examples
---

**Examples**

Examples for this IG:

{% include list-simple-observations.xhtml %}

`todo: generate an example list from preprocessor`


**Examples:** all the examples that are used in this Implementation Guide available for download:

- [XML](examples.xml.zip)
- [JSON](examples.json.zip)
- [TTl](examples.ttl.zip)
